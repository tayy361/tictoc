# Tic-Tac-Toe_in_Csharp
Simple Tic-Tac-Toe Game in C# - Made With Visual Studio

Possible features :^| if i'm not too lazy

-> Wint count
-> Reset win count
-> label to show those count
-> said whose turn is
-> Player Name 
-> AI
